<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">

<html>
<head><title>BrandCoder Account Admin</title>
</head>

<frameset cols="295px,*" frameborder="no">
<frame src="vindex.php" frameborder="0" name="preview" id="preview" scrolling="no">
<frame src="admin.php" frameborder="0" scrolling="no">
</frameset>

</html>