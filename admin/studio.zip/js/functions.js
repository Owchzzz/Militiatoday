
/* Tooltip ====================================== */
$('.tooltip_1').poshytip({
				className: 'tip-twitter',
				showTimeout: 1,
				alignTo: 'target',
				alignX: 'center',
				offsetY: 5,
				allowTipHover: false,
				fade: true,
				slide: true
			}) 
/* form validation ====================================== */			
$("#myform").validate();